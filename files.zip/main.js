(function () {
  const C = window.SITE_CONFIG, L = window.LAPORAN, $ = (s) => document.querySelector(s);
  const rp = (n) => "Rp " + new Intl.NumberFormat("id-ID").format(n);
  const tgl = (d) => new Date(d + "T00:00:00").toLocaleDateString("id-ID", { day: "numeric", month: "short", year: "numeric" });
  let nominal = 0, toastTimer;

  document.querySelectorAll("[data-bind]").forEach((el) => { if (C[el.dataset.bind]) el.textContent = C[el.dataset.bind]; });
  $("#yr").textContent = new Date().getFullYear();
  document.title = "Sedekah Jum'at Berkah " + C.kampus;

  // Hari penutupan pekan ini
  const d = new Date();
  d.setDate(d.getDate() + ((C.hariTutup - d.getDay() + 7) % 7));
  $("#tutup").textContent = d.toLocaleDateString("id-ID", { weekday: "long", day: "numeric", month: "long" });

  function toast(msg) {
    const t = $("#toast"); t.textContent = msg; t.classList.add("on");
    clearTimeout(toastTimer); toastTimer = setTimeout(() => t.classList.remove("on"), 2200);
  }
  function copy(text) {
    const done = () => toast("Tersalin");
    if (navigator.clipboard) return navigator.clipboard.writeText(text).then(done, done);
    const a = document.createElement("textarea"); a.value = text; document.body.appendChild(a);
    a.select(); document.execCommand("copy"); a.remove(); done();
  }

  // Nominal
  $("#chips").innerHTML = C.nominalCepat.map((n) =>
    `<label><input type="radio" name="nom" value="${n}"><span>${rp(n)}</span></label>`).join("");
  document.querySelectorAll("input[name=nom]").forEach((r) => r.addEventListener("change", () => {
    nominal = +r.value; $("#custom").value = ""; update();
  }));
  $("#custom").addEventListener("input", (e) => {
    const v = e.target.value.replace(/\D/g, "").slice(0, 9);
    nominal = +v || 0;
    e.target.value = v ? new Intl.NumberFormat("id-ID").format(v) : "";
    document.querySelectorAll("input[name=nom]").forEach((r) => (r.checked = false));
    update();
  });
  ["#nama", "#anonim"].forEach((s) => $(s).addEventListener("input", update));

  // Metode bayar
  if (C.qrisImage) { $("#qris").src = C.qrisImage; $("#qris-dl").href = C.qrisImage; }
  else { // tanpa QRIS: tampilkan transfer bank saja
    $("#t-qris").hidden = $("#p-qris").hidden = true; $("#p-bank").hidden = false;
    $("#t-bank").setAttribute("aria-selected", true); $(".tabs").style.gridTemplateColumns = "1fr";
  }
  $("#p-bank").innerHTML = C.rekening.map((r, i) =>
    `<div class="bank"><small>${r.bank}</small><b>${r.nomor}</b><small>a.n. ${r.atasNama}</small>
     <button class="btn ghost" data-copy="${i}">Salin nomor rekening</button></div>`).join("");
  document.querySelectorAll("[data-copy]").forEach((b) => b.addEventListener("click", () => copy(C.rekening[b.dataset.copy].nomor)));
  document.querySelectorAll("[role=tab]").forEach((t) => t.addEventListener("click", () => {
    document.querySelectorAll("[role=tab]").forEach((x) => {
      const on = x === t; x.setAttribute("aria-selected", on);
      $("#" + x.getAttribute("aria-controls")).hidden = !on;
    });
  }));

  // Konfirmasi
  function update() {
    const jenis = "Sedekah Jum'at";
    const nama = $("#anonim").checked || !$("#nama").value.trim() ? "Hamba Allah" : $("#nama").value.trim();
    const ok = nominal >= C.nominalMinimal;
    $("#err").hidden = true;
    $("#ringkas").textContent = nominal ? `${jenis} ${rp(nominal)} atas nama ${nama}` : "Pilih nominal untuk melanjutkan.";
    const msg = `Assalamualaikum, saya ingin konfirmasi ${jenis} sebesar ${rp(nominal)} atas nama ${nama}. Bukti transfer saya lampirkan di chat ini. Terima kasih.`;
    const wa = $("#wa");
    wa.href = `https://wa.me/${C.whatsapp}?text=${encodeURIComponent(msg)}`;
    wa.setAttribute("aria-disabled", !ok);
    wa.target = "_blank"; wa.rel = "noopener";
  }
  $("#wa").addEventListener("click", (e) => {
    if (nominal < C.nominalMinimal) {
      e.preventDefault();
      const er = $("#err"); er.hidden = false;
      er.textContent = `Pilih nominal terlebih dahulu. Minimal ${rp(C.nominalMinimal)}.`;
    }
  });
  if (C.googleFormUrl) { const g = $("#gform"); g.href = C.googleFormUrl; g.hidden = false; }
  update();

  // Laporan
  const sum = (k) => L.pekan.reduce((a, p) => a + p[k], 0);
  const masuk = sum("masuk"), salur = sum("salur");
  $("#contoh").hidden = !L.contoh;
  $("#sum").innerHTML = [["Total masuk", masuk], ["Total disalurkan", salur], ["Saldo", masuk - salur]]
    .map(([k, v]) => `<div><dt>${k}</dt><dd>${rp(v)}</dd></div>`).join("");
  const max = Math.max(...L.pekan.map((p) => p.masuk));
  $("#bars").innerHTML = [...L.pekan].reverse().map((p) => `<div style="height:${(p.masuk / max) * 100}%"></div>`).join("");
  $("#rows").innerHTML = L.pekan.map((p) => `<tr><td>${tgl(p.tanggal)}</td><td>${rp(p.masuk)}</td><td>${rp(p.salur)}</td></tr>`).join("");
  $("#salur").innerHTML = L.penyaluran.map((s) =>
    `<article><small>${tgl(s.tanggal)}</small><h3>${s.judul}</h3><p class="amt">${rp(s.jumlah)}</p><p>${s.ket}</p></article>`).join("");
})();
